package DY;

public class DyExecption extends Exception {
    public String getDesc() {
        return desc;
    }

    private String desc;
    DyExecption(String desc){
        super();
        this.desc = desc;
    }
}
