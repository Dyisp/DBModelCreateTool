package DY;

import org.mybatis.generator.config.JDBCConnectionConfiguration;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.*;
import java.util.List;

public class CreateThread extends Thread{
    JPanel contentPanel;
    Map<String, Component> paramCompMap;
    Map<String, Component> tableCompMap;
    public CreateThread(Map<String, Component> paramCompMap,Map<String, Component> tableCompMap){
        this.paramCompMap=paramCompMap;
        this.tableCompMap=tableCompMap;
    }

    public CreateThread(JPanel contentPanel) {
        this.contentPanel = contentPanel;
        Component[] components = contentPanel.getComponents();
        Map<String, Component> paramCompMap = new HashMap<>();
        ComponentUtils.listComponent(paramCompMap, components[0]);
        Map<String, Component> tableCompMap = new HashMap<>();
        ComponentUtils.listComponent(tableCompMap,components[1]);
        this.paramCompMap=paramCompMap;
        this.tableCompMap=tableCompMap;
    }

    @Override
    public void run() {
        Map<String,String> paramValueMap = getCompsValue(paramCompMap,false);
        String dataBaseType = paramValueMap.get(CompsName.DataBaseType);
        String dataBaseIP = paramValueMap.get(CompsName.DataBaseIP);
        String dataBasePort = paramValueMap.get(CompsName.DataBasePort);
        String serviceName = paramValueMap.get(CompsName.ServiceName);
        String userID = paramValueMap.get(CompsName.UserID);
        String password = paramValueMap.get(CompsName.Password);

        try {
            // 测试数据库连接是否可用
            JDBCConnectionConfiguration jdbcConfiguration = ConfigFactory.createJdbcConfiguration(dataBaseType,dataBaseIP,dataBasePort,serviceName,userID,password);
            // 注册驱动
            Class.forName(jdbcConfiguration.getDriverClass());
            // 获取连接
            Connection connection = DriverManager.getConnection(jdbcConfiguration.getConnectionURL(), jdbcConfiguration.getUserId(), jdbcConfiguration.getPassword());
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet tables = metaData.getTables(null, userID, null, new String[]{"TABLE"});
            ExecuteCreateModel.tableNames.clear();
            while(tables.next()){
                String tableName = tables.getString(3);
                ExecuteCreateModel.tableNames.add(tableName);
            }
        }catch (Exception e) {
            e.printStackTrace();
            new DialogThread(WindowStart.massage,null,"数据库连接失败").start();
            return;
        }
        Map<String,String> tableValueMap = getCompsValue(tableCompMap,true);
        Collection<String> values = tableValueMap.values();
        if(values.isEmpty()){
            new DialogThread(WindowStart.massage,null,"请至少输入一个表名！").start();
            return;
        }
        List<String> tableNameList = new ArrayList<>(values);
        Iterator<String> iterator = tableNameList.iterator();
        while (iterator.hasNext()){
            String tableName = iterator.next();
            if(!ExecuteCreateModel.tableNames.contains(tableName)){
                new DialogThread(WindowStart.massage,null,"数据库中不存在["+tableName+"]表！").start();
                return;
            }
        }
        System.out.println("Start to Create DBModels!StartTime:"+(new Date().toString()));
        try {
            setProperties(paramValueMap,tableValueMap);
            ExecuteCreateModel.createModel(paramValueMap,tableValueMap);
            ExecuteCreateModel.complite = true;
            new DialogThread(WindowStart.massage,null,"Model生成结束!").start();
        } catch (DyExecption e) {
            e.printStackTrace();
            new DialogThread(WindowStart.massage,null,e.getDesc()).start();
        }catch (Exception e) {
            e.printStackTrace();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e1) {
            }
            new DialogThread(WindowStart.massage,null,"生成DBModel异常").start();
        }
        System.out.println("Create DBModels End!EndTime:"+(new Date().toString()));
    }

    private void setProperties(Map<String, String> paramValueMap, Map<String, String> tableValueMap) {
        ExecuteCreateModel.properties.setProperty(CompsName.DaoNameAppend,paramValueMap.get(CompsName.DaoNameAppend));
        ExecuteCreateModel.properties.setProperty(CompsName.SqlXmlAppend,paramValueMap.get(CompsName.SqlXmlAppend));
        ExecuteCreateModel.properties.setProperty(CompsName.DaoClassType,paramValueMap.get(CompsName.DaoClassType));
        ExecuteCreateModel.properties.setProperty(CompsName.MakeGetSet,paramValueMap.get(CompsName.MakeGetSet));
        ExecuteCreateModel.properties.setProperty(CompsName.CreatorName,paramValueMap.get(CompsName.CreatorName));
        ExecuteCreateModel.properties.setProperty(CompsName.DBModelRootClassFullPath,paramValueMap.get(CompsName.DBModelRootClassFullPath));
        ExecuteCreateModel.properties.setProperty(CompsName.DBDaoRootClassFullPath,paramValueMap.get(CompsName.DBDaoRootClassFullPath));
    }

    /**
     * 提取窗口组件的值并放入Map
     * @param paramCompMap
     * @param filterEmpty 是否过滤空字符串
     * @return
     */
    private Map<String, String> getCompsValue(Map<String, Component> paramCompMap, boolean filterEmpty) {
        HashMap<String, String> valueMap = new HashMap<>();
        Set<Map.Entry<String, Component>> entries = paramCompMap.entrySet();
        Iterator<Map.Entry<String, Component>> iterator = entries.iterator();
        while (iterator.hasNext()){
            Map.Entry<String, Component> next = iterator.next();
            if(next.getKey() != null){
                Component value = next.getValue();
                if(value instanceof JTextField){
                    if(value.getForeground()!=Color.GRAY){
                        String text = ((JTextField) value).getText();
                        if(value.getName().compareToIgnoreCase(CompsName.DBModelRootClassFullPath)==0){
                            String[] split = text.split("\\.");
                            String rootClassName = split[split.length - 1];
                            valueMap.put(CompsName.DBModelRootClassName,rootClassName);
                            valueMap.put(value.getName(),text);
                        }else if(value.getName().compareToIgnoreCase(CompsName.DBDaoRootClassFullPath)==0){
                            String[] split = text.split("\\.");
                            String rootClassName = split[split.length - 1];
                            valueMap.put(CompsName.DBDaoRootClassName,rootClassName);
                            valueMap.put(value.getName(),text);
                        }else{
                            valueMap.put(value.getName(),text);
                        }
                    }else{
                        // 过滤空值
                        if(!filterEmpty){
                            valueMap.put(value.getName(),"");
                        }
                    }
                }else if(value instanceof JRadioButton){
                    if(value.getName()!=null&&((JRadioButton) value).isSelected()) {
                        if (value.getName().compareToIgnoreCase("class") == 0) {
                            valueMap.put(CompsName.DaoClassType, "Y");
                        } else {
                            valueMap.put(CompsName.DaoClassType, "N");
                        }
                    }
                }else if(value instanceof JCheckBox){
                    boolean selected = ((JCheckBox) value).isSelected();
                    if(value.getName()!=null){
                        if(selected){
                            if(value.getName().compareToIgnoreCase(CompsName.SuppressAllComments)==0){
                                valueMap.put(value.getName(),"false");
                            }else if(value.getName().compareToIgnoreCase(CompsName.MakeGetSet)==0){
                                valueMap.put(value.getName(),"N");
                            }
                        }else{
                            if(value.getName().compareToIgnoreCase(CompsName.SuppressAllComments)==0){
                                valueMap.put(value.getName(),"true");
                            }else if(value.getName().compareToIgnoreCase(CompsName.MakeGetSet)==0){
                                valueMap.put(value.getName(),"Y");
                            }
                        }
                    }
                }else if(value instanceof JComboBox){
                    String actionCommand = (String)((JComboBox) value).getSelectedItem();
                    valueMap.put(value.getName(),actionCommand);
                }
            }
        }
        return valueMap;
    }
}
