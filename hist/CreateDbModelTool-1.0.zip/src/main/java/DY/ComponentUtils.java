package DY;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ComponentUtils {
    /**
     * 递归处理：列出JPanel包含的所有组件（包括其子容器中的组件，不包括子容器）
     * @param compMap
     * @param component
     */
    public static void listComponent(Map<String, Component> compMap, Component component) {
        if(component instanceof JPanel){
            Component[] components = ((JPanel) component).getComponents();
            List<Component> componentList = Arrays.asList(components);
            for(Component componentTemp:componentList){
                listComponent(compMap, componentTemp);
            }
        }else{
            compMap.put(component.getName(),component);
        }
    }

    /**
     * 列出组件包含的所有组件（包括子容器），只向下列一层
     * @param component
     */
    public static Map<String, Component> listSonComp(Component component) {
        Map<String, Component> compMap = new HashMap<>();
        if(component instanceof JPanel || component instanceof JFrame){
            Component[] components = ((JPanel) component).getComponents();
            List<Component> componentList = Arrays.asList(components);
            for(Component componentTemp:componentList){
                compMap.put(componentTemp.getName(),componentTemp);
            }
        }
        return compMap;
    }
}
